import random
import math

# Meir Rosendorff
# Or Hanoch
# Kim <insert indian last name here>
# Devon Jarvis

for pageSize in [1, 5, 10, 15, 20]:

    numBooks = 7
    TrainingPercent = 80
    bookPages = []
    testData = []
    trainingData = []

    for i in range(numBooks):
        bookFile = open("HP" + str(i+1) + ".txt", "r")
        currBook = []
        line = bookFile.readline()
        count = 0
        currLine = str(i)#or edit + " "
        lineNum = 0
        while line:
            if line == "" or line == "\n":
                line = bookFile.readline()
                continue
    # get rid of all punction except ! and ?, but seperate ! and ? from the word they are next to
    # to make them seperate words
            line = line.replace(",", "").replace(".", "").replace("?", " ? ").replace("!", " ! ").replace("\"", "").replace(":", "").replace(";", "").replace("\n", "")
            line = line.replace(")", "").replace("(", "").replace("'", "")
            currLine = currLine + " " + line
            lineNum += 1
            if lineNum ==  pageSize:
                currLine = currLine.lower()
                wordArray = currLine.split(" ")
                currBook.append(wordArray)
                count+=1
                lineNum = 0
                currLine = str(i) + " "
            line = bookFile.readline()

        wordArray = currLine.split(" ")
        currBook.append(wordArray)
        count += 1
        bookPages.append(count)
        bookFile.close()

        random.Random(42).shuffle(currBook)
        allLines = currBook[:]
        numCases = len(currBook)*TrainingPercent/100

        testData = testData + currBook[numCases:]

        trainingData = trainingData + currBook[:numCases]

    numTrainingCases = len(trainingData)
    numTestCases = len(testData)
    print "Num Training Cases: " + str(numTrainingCases)
    print "Num Testing Cases:\t" + str(numTestCases)

    individualProbabilities = [0]*numBooks

    #Calculate the probability of it being any one example
    for i in range(numBooks):
        individualProbabilities[i] = (bookPages[i]* TrainingPercent/100)/float(numTrainingCases)

    words = []
    probabilityTable = []

    # get the probability of each word for each book
    for i in range(len(trainingData)):
        currPage = trainingData[i]
        bookNum = int(trainingData[i][0])
        print "Page " + str(i+1) + " of " + str(numTrainingCases)
        for j in range(1,len(currPage),1): #start at 1 as pos 0 is the bookNumber

            numPerBook = [0.0]*numBooks #array to count how many times word appears per book
            word = currPage[j] #iterate over the words
            if word in words or word == "": #if the word is blank or its already been seen skip
                continue
            else:
                numPerBook[bookNum] += 1 #add one for the word we just read

            for k in range(i+1, len(trainingData), 1): #iterate through the remaining pages checking for the word
                if word in trainingData[k]:
                    currNum = int(trainingData[k][0])
                    numPerBook[currNum]+=1

            words.append(word) # add the word to my word list
            probabilities = [0.0]*numBooks
            for k in range(numBooks):# calculate the probability for that word
                probabilities[k] = (numPerBook[k]+1) / (bookPages[k] + numBooks)
            probabilityTable.append(probabilities)



    # Save Probabilities to probabilities.txt
    # format is word P(book1) P(book2) ...

    probabiltyFile = open("probabilitiesPS" + str(pageSize) + ".txt", "w")

    for i in range(len(words)):
        line = words[i]
        for j in range(numBooks):
            line = line + " " + str(probabilityTable[i][j])
        line = line + "\n"
        probabiltyFile.write(line)

    probabiltyFile.close()

    # read in from probability files

    probFile = open("probabilitiesPS" + str(pageSize) + ".txt", "r")

    line = probFile.readline()

    while line:

        probs = line.split(" ")
        words.append(probs[0])
        probabilities = []

        for i in range(1, numBooks+1, 1):
            probabilities.append(float(probs[i]))

        probabilityTable.append(probabilities)
        line = probFile.readline()

    for i in range(numBooks):
        pos = words.index(str(i))
        words.pop(pos)
        probabilityTable.pop(i)

    # Testing Time
    confusionMatrix = [[0]*numBooks for i in range(numBooks)]

    cmStorage = open("confusionMatrix.txt", "a")

    cmStorage.write("Page size: " + str(pageSize) + " paragraphs\n")
    cmStorage.write("Num Training Lines: " + str(numTrainingCases) + "\n")
    cmStorage.write("Num Testing Cases:\t" + str(numTestCases) + "\n")

    # print "Word[0]"
    # print words[0]
    # print probabilityTable[0]

    pageNum = 0
    numCorrect = 0.0
    numIncorrect = 0.0
    for page in testData:

        print "Testing Page Number: " + str(pageNum) + "\tof\t" + str(numTestCases)

        pageNum += 1

        caseProbabilities = [1] * numBooks

        for i in range(len(words)):
            currWord = words[i]

            included = 0
            if currWord in page:
                included = 1

            for j in range(numBooks):
                prob = probabilityTable[i][j]
                caseProbabilities[j] += math.log(((0.0+included)*prob) + ((1.0-included)*(1.0-prob)))

        posteriorProbabilities = []
        for i in range(numBooks):
            posteriorProbabilities.append(caseProbabilities[i]+math.log(individualProbabilities[i]))

        probabilityOfAll = sum(posteriorProbabilities)
        for i in range(numBooks):
            posteriorProbabilities[i] -= probabilityOfAll


        max = posteriorProbabilities[0]
        maxPos = 0
        for i in range(numBooks):
            if max < posteriorProbabilities[i]:
                maxPos = i
                max = posteriorProbabilities[i]
        if maxPos == int(page[0]):
            numCorrect+=  1
        else:
            numIncorrect += 1
        confusionMatrix[maxPos][int(page[0])] += 1

    cmStorage.write("Percentage Correct:\t" + str(numCorrect/numTestCases*100) + "\n")
    cmStorage.write("Percentage Incorrect:\t" + str(numIncorrect / numTestCases * 100) + "\n\n")
    topLine = " "
    barrierLine = "-"
    for i in range(numBooks):
        topLine += "\t|\t" + str(i+1)
        barrierLine += "---|----"
    topLine += "\t|"
    barrierLine += "---|"
    print topLine
    print barrierLine
    cmStorage.write(topLine + "\n")
    cmStorage.write(barrierLine + "\n")

    for i in range(numBooks):
        topLine = ""
        topLine += str(i+1) + " "
        for j in range(numBooks):
            topLine += "\t|\t" + str(confusionMatrix[i][j])
        print topLine + "\t|"
        cmStorage.write(topLine + "\n")
    cmStorage.write("\n\n")
    cmStorage.close()